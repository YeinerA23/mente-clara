# ============================================================
# Mente Clara · Inicialización de base de datos SQLite
# Ejecutar: python init_db.py   (crea mente_clara.db)
# ============================================================
import os
import sqlite3

DB_FILE = os.environ.get('DB_FILE', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mente_clara.db'))

SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  apellidos TEXT NOT NULL DEFAULT '',
  correo TEXT NOT NULL UNIQUE,
  telefono TEXT NOT NULL DEFAULT '',
  fecha_nacimiento TEXT,
  genero TEXT NOT NULL DEFAULT 'prefiero_no_decir',
  foto TEXT NOT NULL DEFAULT 'default.png',
  clave TEXT NOT NULL,
  rol TEXT NOT NULL DEFAULT 'usuario',
  activo INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS psicologos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  especialidad TEXT NOT NULL,
  bio TEXT,
  formacion TEXT,
  certificaciones TEXT,
  foto TEXT NOT NULL DEFAULT 'default.png',
  email TEXT,
  telefono TEXT,
  activo INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS servicios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  descripcion TEXT NOT NULL,
  icono TEXT NOT NULL DEFAULT 'bi-heart',
  imagen TEXT,
  beneficios TEXT,
  duracion_min INTEGER NOT NULL DEFAULT 50,
  precio REAL,
  activo INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS citas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  servicio_id INTEGER,
  psicologo_id INTEGER,
  nombre_completo TEXT NOT NULL,
  telefono TEXT NOT NULL,
  email TEXT,
  servicio TEXT NOT NULL,
  fecha TEXT NOT NULL,
  hora TEXT NOT NULL,
  modalidad TEXT NOT NULL DEFAULT 'virtual',
  estado TEXT NOT NULL DEFAULT 'pendiente',
  notas TEXT,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (servicio_id) REFERENCES servicios(id) ON DELETE SET NULL,
  FOREIGN KEY (psicologo_id) REFERENCES psicologos(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS testimonios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER,
  nombre TEXT NOT NULL,
  ocupacion TEXT DEFAULT '',
  texto TEXT NOT NULL,
  calificacion INTEGER NOT NULL DEFAULT 5,
  aprobado INTEGER NOT NULL DEFAULT 0,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS categorias_blog (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  descripcion TEXT
);

CREATE TABLE IF NOT EXISTS articulos_blog (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  categoria_id INTEGER,
  titulo TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  resumen TEXT NOT NULL,
  contenido TEXT NOT NULL,
  imagen TEXT,
  autor TEXT NOT NULL DEFAULT 'Dr. Yeiner Palacios',
  publicado INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias_blog(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS contactos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  email TEXT NOT NULL,
  telefono TEXT DEFAULT '',
  asunto TEXT NOT NULL,
  mensaje TEXT NOT NULL,
  leido INTEGER NOT NULL DEFAULT 0,
  creado_en TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

ADMIN_HASH = 'scrypt:32768:8:1$dfsrtFNMmBfcbksC$669734e6399e108587acd72c78802a18ba50950adedf2fddb0758124514ab584fd21dff5da34354a93d14d603c61f898093ab00dc1aa947c60c7e78a37ded840'


def conectar(path=DB_FILE):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def crear_tablas(conn):
    conn.executescript(SCHEMA)


def seed(conn):
    if conn.execute('SELECT COUNT(*) AS n FROM servicios').fetchone()['n'] > 0:
        return
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia Individual', 'terapia-individual', 'Sesiones personalizadas para trabajar ansiedad, autoestima, duelo, depresión y momentos de transición vital.', 'bi-person', ?1, 50, 80000)""",
        ('• Autoconocimiento profundo\n• Manejo de ansiedad y estrés\n• Mejora de autoestima\n• Herramientas prácticas para el día a día',))
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia de Pareja', 'terapia-de-pareja', 'Espacio neutral y seguro para mejorar la comunicación y fortalecer el vínculo afectivo entre ambos.', 'bi-people', ?1, 80, 120000)""",
        ('• Mejora de la comunicación\n• Resolución de conflictos\n• Reconstrucción de confianza\n• Fortalecimiento del vínculo',))
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia Familiar', 'terapia-familiar', 'Trabajo con familias para mejorar dinámicas, resolver conflictos intergeneracionales y fortalecer lazos.', 'bi-house-heart', ?1, 90, 140000)""",
        ('• Mejora dinámicas familiares\n• Resolución de conflictos\n• Comunicación efectiva\n• Fortalecimiento de vínculos',))
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia Infantil', 'terapia-infantil', 'Acompañamiento especializado para niños y adolescentes, utilizando juego, arte y técnicas adaptadas.', 'bi-balloon', ?1, 50, 75000)""",
        ('• Expresión emocional segura\n• Manejo de conductas\n• Habilidades sociales\n• Apoyo en transiciones',))
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia para Ansiedad', 'terapia-ansiedad', 'Tratamiento especializado en trastornos de ansiedad, ataques de pánico y fobias.', 'bi-activity', ?1, 50, 80000)""",
        ('• Reducción de síntomas\n• Técnicas de relajación\n• Restructuración cognitiva\n• Prevención de recaídas',))
    conn.execute("""INSERT INTO servicios (nombre, slug, descripcion, icono, beneficios, duracion_min, precio) VALUES
        ('Terapia para Depresión', 'terapia-depresion', 'Acompañamiento profesional para superar episodios depresivos y recuperar la motivación.', 'bi-cloud-sun', ?1, 50, 80000)""",
        ('• Mejora del estado de ánimo\n• Activación conductual\n• Cambio de patrones negativos\n• Prevención de recaídas',))

    conn.executemany("INSERT INTO categorias_blog (nombre, slug, descripcion) VALUES (?, ?, ?)", [
        ('Ansiedad', 'ansiedad', 'Artículos sobre manejo de la ansiedad'),
        ('Estrés', 'estres', 'Estrategias para el manejo del estrés'),
        ('Autoestima', 'autoestima', 'Construcción de autoestima saludable'),
        ('Depresión', 'depresion', 'Información y herramientas'),
        ('Inteligencia Emocional', 'inteligencia-emocional', 'Habilidades emocionales'),
        ('Manejo de Emociones', 'manejo-de-emociones', 'Técnicas para regular emociones'),
    ])

    conn.executemany("""INSERT INTO articulos_blog (categoria_id, titulo, slug, resumen, contenido, autor) VALUES (?, ?, ?, ?, ?, ?)""", [
        (1, '5 técnicas para calmarte en un momento de ansiedad', '5-tecnicas-ansiedad',
         'Estrategias prácticas que puedes aplicar ahora mismo cuando la ansiedad se apodera de ti.',
         '<p>La ansiedad puede aparecer en cualquier momento. Existen técnicas sencillas y efectivas para recuperar la calma.</p><h3>1. Respiración diafragmática</h3><p>Inhala por la nariz contando hasta 4, mantén 4 segundos y exhala por la boca contando hasta 6. Repite 5 veces.</p><h3>2. Anclaje sensorial 5-4-3-2-1</h3><p>Identifica 5 cosas que veas, 4 que toques, 3 que escuches, 2 que huelas y 1 que pruebes.</p><h3>3. Relajación muscular progresiva</h3><p>Tensa y relaja cada grupo muscular durante 5 segundos, de pies a cabeza.</p><h3>4. Escritura express</h3><p>Escribe 3 minutos todo lo que sientes sin juzgar.</p><h3>5. Movimiento consciente</h3><p>Caminar, estirar o bailar suavemente reduce el cortisol y libera endorfinas.</p>',
         'Dr. Yeiner Palacios'),
        (2, 'Cómo el estrés crónico afecta tu cuerpo y mente', 'estres-cronico-efectos',
         'El estrés no gestionado tiene consecuencias profundas en salud física y mental.',
         '<p>El estrés crónico puede causar dolores de cabeza, tensión muscular, problemas digestivos e insomnio.</p><h3>Efectos emocionales</h3><p>Irritabilidad, dificultad para concentrarse, olvidos y sensación de estar abrumado.</p><h3>Estrategias de manejo</h3><p>Establecer límites, practicar relajación, ejercicio y buscar apoyo profesional.</p>',
         'Dr. Yeiner Palacios'),
        (3, 'Construye una autoestima sólida: guía práctica', 'autoestima-guia-practica',
         'La autoestima no es egoísmo, es el fundamento para relaciones sanas y metas con confianza.',
         '<p>La autoestima saludable permite enfrentar desafíos y establecer límites.</p><h3>Reconoce tu diálogo interno</h3><p>Cambia el diálogo negativo por autocompasión.</p><h3>Celebra tus logros</h3><p>Registra tus logros diarios.</p><h3>Establece límites</h3><p>Saber decir "no" es amor propio.</p>',
         'Dr. Yeiner Palacios'),
        (4, 'Señales de que podrías estar experimentando depresión', 'senales-depresion',
         'Reconocer los síntomas a tiempo es el primer paso para recuperar tu bienestar.',
         '<p>La depresión afecta energía, concentración e interés por las cosas.</p><h3>Señales emocionales</h3><p>Tristeza persistente, vacío, desesperanza, irritabilidad.</p><h3>Señales físicas</h3><p>Cambios de peso, fatiga, dolores sin causa médica.</p><h3>¿Qué hacer?</h3><p>Si dura más de 2 semanas, busca ayuda profesional.</p>',
         'Dr. Yeiner Palacios'),
        (5, '¿Qué es la inteligencia emocional y por qué importa?', 'inteligencia-emocional-importa',
         'Entender y gestionar emociones transforma relaciones, trabajo y vida entera.',
         '<p>La inteligencia emocional es reconocer, comprender y gestionar emociones propias y ajenas.</p><h3>Los 5 componentes</h3><p>Autoconocimiento, autorregulación, motivación, empatía y habilidades sociales.</p><h3>¿Cómo desarrollarla?</h3><p>Atención plena, diario emocional, pausar antes de reaccionar, escuchar activamente.</p>',
         'Dr. Yeiner Palacios'),
        (6, 'Guía para manejar tus emociones en momentos difíciles', 'guia-manejo-emociones',
         'Las emociones intensas no tienen por qué controlarte. Aprende a navegarlas.',
         '<p>Aprender a regular emociones es esencial para la salud mental.</p><h3>Valida lo que sientes</h3><p>No hay emociones buenas ni malas.</p><h3>Nombra la emoción</h3><p>Ponerle nombre reduce su intensidad.</p><h3>Busca la causa</h3><p>Pregúntate qué está causando la emoción.</p><h3>Respira antes de actuar</h3><p>3 respiraciones profundas antes de reaccionar.</p>',
         'Dr. Yeiner Palacios'),
    ])

    conn.executemany("""INSERT INTO testimonios (nombre, ocupacion, texto, calificacion, aprobado) VALUES (?, ?, ?, ?, ?)""", [
        ('Camila Rodríguez', 'Diseñadora gráfica', 'Llegué a terapia sintiéndome perdida. Después de meses, aprendí a reconocer mis emociones y cuidarme mejor. El espacio fue increíblemente seguro.', 5, 1),
        ('Andrés Felipe Mora', 'Ingeniero de sistemas', 'La terapia me ayudó a manejar mi ansiedad laboral. Las herramientas que aprendí las aplico cada día.', 5, 1),
        ('Valentina Herrera', 'Docente', 'Después de años con autoestima baja, encontré un espacio donde aprendí a valorarme. La doctora tiene una capacidad increíble de hacerte sentir escuchado.', 5, 1),
        ('Santiago López', 'Emprendedor', 'Empecé terapia por crisis de pareja y descubrí mucho sobre mí mismo. Fue transformador.', 5, 1),
        ('María Fernanda Ospina', 'Contadora', 'Pasé por un momento muy difícil tras la pérdida de mi madre. La terapia me dio herramientas para procesar mi dolor.', 5, 1),
        ('Daniel Cardona', 'Estudiante', 'El estrés era mi compañero constante. Aprendí técnicas que cambiaron mi forma de enfrentar la presión académica.', 4, 1),
    ])

    conn.execute("""INSERT INTO psicologos (nombre, especialidad, bio, formacion, certificaciones, email, telefono) VALUES (?, ?, ?, ?, ?, ?, ?)""",
        ('Dr. Yeiner Palacios', 'Psicología Clínica',
         'Psicólogo clínico con más de 8 años de experiencia. Especializado en terapia cognitivo-conductual, mindfulness clínico y manejo de la ansiedad. Mi enfoque se centra en la persona, con un acompañamiento cálido, empático y basado en evidencia.',
         'Licenciatura en Psicología - Universidad Nacional\nMaestría en Psicología Clínica - Universidad del Valle\nFormación en Terapia Cognitivo-Conductual',
         'Certificación en Mindfulness Clínico (MBSR)\nDiplomado en Psicología Positiva\nCertificación en Terapia breve de pareja',
         'dr.palacios@menteclara.com', '+57 300 123 4567'))

    conn.execute("""INSERT INTO usuarios (nombre, apellidos, correo, rol, clave) VALUES (?, ?, ?, 'admin', ?)""",
        ('Administrador', 'Mente Clara', 'admin@menteclara.com', ADMIN_HASH))


if __name__ == '__main__':
    conn = conectar()
    crear_tablas(conn)
    seed(conn)
    conn.close()
    print('Base de datos lista:', DB_FILE)
