# ============================================================
# Mente Clara · Capa de base de datos
# SQLite por defecto (gratis y sin servidor) ·
# MySQL opcional vía variable de entorno DB_DRIVER=mysql
# ============================================================
import os
import datetime
import sqlite3
from dotenv import load_dotenv

load_dotenv()

DRIVER = os.environ.get('DB_DRIVER', 'sqlite').lower()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# ---------- Conversión de tipos (SQLite) ----------
def _convert(value):
    """Convierte cadenas ISO de SQLite a date/time/datetime para que
    los templates con .strftime() sigan funcionando como con MySQL."""
    if isinstance(value, str) and value:
        n = len(value)
        if n == 10 and value[4] == '-' and value[7] == '-':
            try:
                return datetime.date.fromisoformat(value)
            except ValueError:
                pass
        elif n == 8 and value[2] == ':' and value[5] == ':':
            try:
                return datetime.time.fromisoformat(value)
            except ValueError:
                pass
        elif n == 5 and value[2] == ':':
            try:
                return datetime.time.fromisoformat(value + ':00')
            except ValueError:
                pass
        elif n >= 19 and value[4] == '-' and value[10] in (' ', 'T'):
            try:
                return datetime.datetime.strptime(value[:19].replace('T', ' '), '%Y-%m-%d %H:%M:%S')
            except ValueError:
                pass
    return value


def _dict_factory(cursor, row):
    return {col[0]: _convert(row[idx]) for idx, col in enumerate(cursor.description)}


def _translate_sql(sql):
    return sql.replace('RAND()', 'RANDOM()').replace('%s', '?')


# ---------- Conexiones ----------
def _mysql_connect():
    import mysql.connector
    return mysql.connector.connect(
        host=os.environ.get('DB_HOST', 'localhost'),
        user=os.environ.get('DB_USER', 'root'),
        password=os.environ.get('DB_PASSWORD', ''),
        database=os.environ.get('DB_NAME', 'mente_clara_db'),
        autocommit=True,
    )


def _sqlite_connect():
    path = os.environ.get('DB_FILE', os.path.join(BASE_DIR, 'mente_clara.db'))
    conn = sqlite3.connect(path)
    conn.row_factory = _dict_factory
    conn.isolation_level = None  # modo autocommit
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


class _Cursor:
    def __init__(self, cur):
        self._cur = cur

    def execute(self, sql, params=None):
        if DRIVER == 'sqlite':
            sql = _translate_sql(sql)
        self._cur.execute(sql, params if params is not None else ())

    def executemany(self, sql, params_list):
        if DRIVER == 'sqlite':
            sql = _translate_sql(sql)
        self._cur.executemany(sql, params_list)

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    @property
    def lastrowid(self):
        return self._cur.lastrowid

    def close(self):
        self._cur.close()


class _Connection:
    def __init__(self):
        self._conn = _sqlite_connect() if DRIVER == 'sqlite' else _mysql_connect()

    def cursor(self, dictionary=False):
        if DRIVER == 'mysql':
            return _Cursor(self._conn.cursor(dictionary=dictionary))
        return _Cursor(self._conn.cursor())

    def commit(self):
        self._conn.commit()

    def close(self):
        self._conn.close()


def get_db():
    return _Connection()
