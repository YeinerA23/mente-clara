/* ============================================================
   Mente Clara · JavaScript principal
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Navbar scroll ---------- */
  const navbar = document.querySelector('.navbar-mc');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 30);
    });
  }

  /* ---------- Avatar dropdown ---------- */
  const avatarBtn = document.querySelector('.avatar-btn');
  const avatarDropdown = document.querySelector('.avatar-dropdown');
  if (avatarBtn && avatarDropdown) {
    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      avatarDropdown.classList.toggle('show');
    });
    document.addEventListener('click', (e) => {
      if (!avatarDropdown.contains(e.target)) avatarDropdown.classList.remove('show');
    });
  }

  /* ---------- Password toggle ---------- */
  document.querySelectorAll('.password-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const wrap = btn.closest('.input-group, .position-relative');
      if (!wrap) return;
      const input = wrap.querySelector('input[type="password"], input[type="text"]');
      if (!input) return;
      const isP = input.type === 'password';
      input.type = isP ? 'text' : 'password';
      btn.innerHTML = isP ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    });
  });

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const wasActive = item.classList.contains('active');
      document.querySelectorAll('.faq-item.active').forEach(i => i.classList.remove('active'));
      if (!wasActive) item.classList.add('active');
    });
  });

  /* ---------- Flash messages → SweetAlert2 ---------- */
  const flashData = document.getElementById('flash-data');
  if (flashData) {
    const tipo = flashData.dataset.tipo;
    const mensaje = flashData.dataset.mensaje;
    if (mensaje) {
      const iconMap = { 'exito':'success', 'success':'success', 'error':'error', 'danger':'error', 'info':'info', 'warning':'warning' };
      const titleMap = { 'exito':'¡Éxito!', 'success':'¡Éxito!', 'error':'Error', 'danger':'Error', 'info':'Información', 'warning':'Advertencia' };
      const isShort = tipo === 'exito' || tipo === 'success';
      Swal.fire({
        icon: iconMap[tipo] || 'info',
        title: titleMap[tipo] || 'Mensaje',
        text: mensaje,
        confirmButtonColor: '#7C5CBF',
        customClass: { popup: 'swal-mc' },
        timer: isShort ? 4000 : undefined,
        timerProgressBar: isShort
      });
    }
  }

  /* ---------- Confirm actions ---------- */
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const url = el.href || el.dataset.url;
      const texto = el.dataset.confirm || '¿Estás seguro?';
      Swal.fire({
        title: '¿Confirmar?',
        text: texto,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#7C5CBF',
        cancelButtonColor: '#DC6B6B',
        confirmButtonText: 'Sí, confirmar',
        cancelButtonText: 'Cancelar',
        customClass: { popup: 'swal-mc' }
      }).then((result) => {
        if (result.isConfirmed) {
          if (el.tagName === 'FORM') el.submit();
          else if (url) window.location.href = url;
        }
      });
    });
  });

  /* ---------- Scroll animations ---------- */
  const animEls = document.querySelectorAll('.animate-on-scroll');
  if (animEls.length && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in-up');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    animEls.forEach(el => obs.observe(el));
  }

  /* ---------- Mobile nav close ---------- */
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const show = document.querySelector('.navbar-collapse.show');
      if (show) {
        const inst = bootstrap.Collapse.getInstance(show) || new bootstrap.Collapse(show, { toggle: false });
        inst.hide();
      }
    });
  });

  /* ---------- Confirm logout ---------- */
  document.querySelectorAll('[data-logout]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const url = el.href;
      Swal.fire({
        title: '¿Cerrar sesión?',
        text: 'Serás redirigido al inicio de sesión.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#7C5CBF',
        cancelButtonColor: '#6B7280',
        confirmButtonText: 'Sí, cerrar sesión',
        cancelButtonText: 'Cancelar',
        customClass: { popup: 'swal-mc' }
      }).then((r) => { if (r.isConfirmed) window.location.href = url; });
    });
  });

  /* ---------- Image preview ---------- */
  document.querySelectorAll('.image-preview-input').forEach(input => {
    const preview = document.querySelector(input.dataset.preview);
    if (!preview) return;
    input.addEventListener('change', () => {
      const file = input.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => { preview.src = e.target.result; };
        reader.readAsDataURL(file);
      }
    });
  });

});
