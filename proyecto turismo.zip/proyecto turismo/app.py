import os
import json
import pymysql
import pymysql.cursors
from datetime import datetime
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, g, abort, jsonify
)

app = Flask(__name__)
app.secret_key = 'choco-turismo-secret-key-2026'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'img')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

DB_CONFIG = {
    'host': os.environ.get('DB_HOST', 'localhost'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASS', ''),
    'database': os.environ.get('DB_NAME', 'turismo_choco'),
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

DESTINOS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'destinos.json')


def get_db():
    if 'db' not in g:
        g.db = pymysql.connect(**DB_CONFIG)
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    temp_config = DB_CONFIG.copy()
    temp_config.pop('database')
    try:
        conn = pymysql.connect(**temp_config)
        with conn.cursor() as cursor:
            cursor.execute("CREATE DATABASE IF NOT EXISTS turismo_choco CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn.close()
    except Exception as e:
        print(f"[INFO] Usando base de datos existente: {e}")

    db = get_db()
    with db.cursor() as cursor:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                rol VARCHAR(20) NOT NULL DEFAULT 'usuario',
                fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        cursor.execute("SELECT id FROM usuarios WHERE email = %s", ('admin@choco.gov.co',))
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO usuarios (nombre, email, password, rol) VALUES (%s, %s, %s, %s)",
                ('Administrador', 'admin@choco.gov.co', generate_password_hash('admin123'), 'administrador')
            )
    db.commit()


def load_destinos():
    if os.path.exists(DESTINOS_PATH):
        with open(DESTINOS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []


def save_destinos(destinos):
    with open(DESTINOS_PATH, 'w', encoding='utf-8') as f:
        json.dump(destinos, f, ensure_ascii=False, indent=2)


def get_destino_by_id(destino_id):
    destinos = load_destinos()
    for d in destinos:
        if d['id'] == destino_id:
            return d
    return None


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_imagen(file):
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        nombre = f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{os.urandom(4).hex()}.{ext}"
        file.save(os.path.join(UPLOAD_FOLDER, nombre))
        return url_for('static', filename=f'img/{nombre}')
    return None


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesion para acceder.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesion para acceder.', 'warning')
            return redirect(url_for('login'))
        if session.get('rol') != 'administrador':
            flash('No tienes permisos para acceder a esta seccion.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


@app.context_processor
def inject_user():
    return {
        'logged_in': 'user_id' in session,
        'user_nombre': session.get('nombre', ''),
        'user_rol': session.get('rol', ''),
        'now': datetime.now()
    }


@app.route('/')
def index():
    destinos = load_destinos()
    categorias = list(set(d.get('categoria', '') for d in destinos))
    municipios = list(set(d.get('municipio', '') for d in destinos))
    return render_template('index.html', destinos=destinos[:6], categorias=categorias, municipios=municipios)


@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if 'user_id' in session:
        return redirect(url_for('index'))
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not nombre or not email or not password:
            flash('Todos los campos son obligatorios.', 'danger')
            return redirect(url_for('registro'))
        if password != confirm_password:
            flash('Las contrasenas no coinciden.', 'danger')
            return redirect(url_for('registro'))
        if len(password) < 6:
            flash('La contrasena debe tener al menos 6 caracteres.', 'danger')
            return redirect(url_for('registro'))

        db = get_db()
        with db.cursor() as cursor:
            cursor.execute("SELECT id FROM usuarios WHERE email = %s", (email,))
            if cursor.fetchone():
                flash('El correo electronico ya esta registrado.', 'danger')
                return redirect(url_for('registro'))
            cursor.execute(
                "INSERT INTO usuarios (nombre, email, password, rol) VALUES (%s, %s, %s, %s)",
                (nombre, email, generate_password_hash(password), 'usuario')
            )
        db.commit()
        flash('Registro exitoso. Ahora puedes iniciar sesion.', 'success')
        return redirect(url_for('login'))
    return render_template('registro.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        if not email or not password:
            flash('Completa todos los campos.', 'danger')
            return redirect(url_for('login'))

        db = get_db()
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM usuarios WHERE email = %s", (email,))
            user = cursor.fetchone()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['nombre'] = user['nombre']
            session['email'] = user['email']
            session['rol'] = user['rol']
            flash(f'Bienvenido, {user["nombre"]}!', 'success')
            if user['rol'] == 'administrador':
                return redirect(url_for('admin_panel'))
            return redirect(url_for('index'))
        else:
            flash('Correo o contrasena incorrectos.', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Has cerrado sesion correctamente.', 'info')
    return redirect(url_for('index'))


@app.route('/destinos')
def destinos():
    destinos_list = load_destinos()
    categoria = request.args.get('categoria', '')
    municipio = request.args.get('municipio', '')
    busqueda = request.args.get('q', '')

    if busqueda:
        destinos_list = [d for d in destinos_list if busqueda.lower() in d.get('nombre', '').lower() or busqueda.lower() in d.get('descripcion', '').lower()]
    if categoria:
        destinos_list = [d for d in destinos_list if d.get('categoria') == categoria]
    if municipio:
        destinos_list = [d for d in destinos_list if d.get('municipio') == municipio]

    categorias = list(set(d.get('categoria', '') for d in load_destinos()))
    municipios = list(set(d.get('municipio', '') for d in load_destinos()))
    return render_template('destinos.html', destinos=destinos_list, categorias=categorias, municipios=municipios, busqueda=busqueda, categoria_actual=categoria, municipio_actual=municipio)


@app.route('/destino/<int:destino_id>')
def detalle_destino(destino_id):
    destino = get_destino_by_id(destino_id)
    if not destino:
        abort(404)
    return render_template('detalle.html', destino=destino)


@app.route('/admin')
@admin_required
def admin_panel():
    destinos = load_destinos()
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM usuarios ORDER BY fecha_registro DESC")
        usuarios = cursor.fetchall()
    return render_template('admin/panel.html', destinos=destinos, usuarios=usuarios)


@app.route('/admin/destinos/nuevo', methods=['GET', 'POST'])
@admin_required
def admin_nuevo_destino():
    if request.method == 'POST':
        destinos = load_destinos()
        nuevo_id = max([d['id'] for d in destinos], default=0) + 1

        imagen = save_imagen(request.files.get('imagen_file'))
        if not imagen:
            imagen = request.form.get('imagen_url', '').strip()

        nuevo = {
            'id': nuevo_id,
            'nombre': request.form.get('nombre', '').strip(),
            'municipio': request.form.get('municipio', '').strip(),
            'categoria': request.form.get('categoria', '').strip(),
            'descripcion': request.form.get('descripcion', '').strip(),
            'descripcion_detallada': request.form.get('descripcion_detallada', '').strip(),
            'imagen': imagen,
            'coordenadas': request.form.get('coordenadas', '').strip(),
            'acceso': request.form.get('acceso', '').strip(),
            'actividades': request.form.get('actividades', '').strip(),
        }
        if not nuevo['nombre'] or not nuevo['municipio'] or not nuevo['categoria']:
            flash('Nombre, municipio y categoria son obligatorios.', 'danger')
            return render_template('admin/form_destino.html', destino=nuevo, accion='Crear')
        destinos.append(nuevo)
        save_destinos(destinos)
        flash('Destino turistico creado exitosamente.', 'success')
        return redirect(url_for('admin_panel'))
    return render_template('admin/form_destino.html', destino=None, accion='Crear')


@app.route('/admin/destinos/editar/<int:destino_id>', methods=['GET', 'POST'])
@admin_required
def admin_editar_destino(destino_id):
    destinos = load_destinos()
    destino = get_destino_by_id(destino_id)
    if not destino:
        abort(404)
    if request.method == 'POST':
        for key in ['nombre', 'municipio', 'categoria', 'descripcion', 'descripcion_detallada', 'coordenadas', 'acceso', 'actividades']:
            destino[key] = request.form.get(key, '').strip()

        imagen_file = save_imagen(request.files.get('imagen_file'))
        if imagen_file:
            destino['imagen'] = imagen_file
        elif request.form.get('imagen_url', '').strip():
            destino['imagen'] = request.form.get('imagen_url', '').strip()
        for i, d in enumerate(destinos):
            if d['id'] == destino_id:
                destinos[i] = destino
                break
        save_destinos(destinos)
        flash('Destino actualizado correctamente.', 'success')
        return redirect(url_for('admin_panel'))
    return render_template('admin/form_destino.html', destino=destino, accion='Editar')


@app.route('/admin/destinos/eliminar/<int:destino_id>', methods=['POST'])
@admin_required
def admin_eliminar_destino(destino_id):
    destinos = load_destinos()
    destinos = [d for d in destinos if d['id'] != destino_id]
    save_destinos(destinos)
    flash('Destino eliminado correctamente.', 'success')
    return redirect(url_for('admin_panel'))


@app.route('/admin/usuarios')
@admin_required
def admin_usuarios():
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT * FROM usuarios ORDER BY fecha_registro DESC")
        usuarios = cursor.fetchall()
    return render_template('admin/usuarios.html', usuarios=usuarios)


@app.route('/admin/usuarios/eliminar/<int:user_id>', methods=['POST'])
@admin_required
def admin_eliminar_usuario(user_id):
    if user_id == session.get('user_id'):
        flash('No puedes eliminar tu propia cuenta.', 'danger')
        return redirect(url_for('admin_usuarios'))
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("DELETE FROM usuarios WHERE id = %s", (user_id,))
    db.commit()
    flash('Usuario eliminado correctamente.', 'success')
    return redirect(url_for('admin_usuarios'))


@app.route('/admin/usuarios/cambiar-rol/<int:user_id>', methods=['POST'])
@admin_required
def admin_cambiar_rol(user_id):
    if user_id == session.get('user_id'):
        flash('No puedes cambiar tu propio rol.', 'danger')
        return redirect(url_for('admin_usuarios'))
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("SELECT rol FROM usuarios WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if user:
            nuevo_rol = 'usuario' if user['rol'] == 'administrador' else 'administrador'
            cursor.execute("UPDATE usuarios SET rol = %s WHERE id = %s", (nuevo_rol, user_id))
    db.commit()
    flash(f'Rol cambiado a {nuevo_rol} correctamente.', 'success')
    return redirect(url_for('admin_usuarios'))


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


if __name__ == '__main__':
    with app.app_context():
        init_db()
    destinos_iniciales = [
        {
            "id": 1,
            "nombre": "Nuqui",
            "municipio": "Nuqui",
            "categoria": "Playa",
            "descripcion": "Puerta de entrada al Choco, Nuqui ofrece playas virgin, selva tropical y una cultura afrocolombiana unica.",
            "descripcion_detallada": "Nuqui es un municipio ubicado en la costa pacifica del Choco, conocido por sus playas virgin, aguas termales y la rica biodiversidad de su selva tropical. Es el punto de partida ideal para explorar laendregion del Choco, con acceso a comunidades afrocolombianas y raizales que mantienen vivas sus tradiciones ancestrales. Las playas de Nuqui, como Guachalito y Coqui, ofrecen experiencias unicas de surfing, avistamiento de ballenas y trekking por la selva.",
            "imagen": "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
            "coordenadas": "2.2361° N, 77.5244° W",
            "acceso": "Por avion desde Medellin (1 hora) o por mar desde Buenaventura",
            "actividades": "Surf, avistamiento de ballenas, senderismo, termas de Nuqui, pesca deportiva"
        },
        {
            "id": 2,
            "nombre": "Isla Gorgona",
            "municipio": "Guapi",
            "categoria": "Isla",
            "descripcion": "Antigua prision colonial convertida en parque nacional, famosa por su vida marina y senderos en la selva.",
            "descripcion_detallada": "La Isla Gorgona fue durante decadas una de las prisiones mas temidas de Colombia. Hoy es un Parque Nacional Natural que alberga una asombrosa biodiversidad tanto terrestre como marina. Sus aguas son refuge de ballenas jorobadas entre julio y octubre, y sus selvas albergan especies endemicas como el mono aullador. Los visitantes pueden recorrer los antiguos pabellones carcelarios, hacer senderismo por la selva y bucear en sus arrecifes de coral.",
            "imagen": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800",
            "coordenadas": "2.9667° N, 78.1833° W",
            "acceso": "Lancha desde Guapi o Buenaventura (aproximadamente 3 horas)",
            "actividades": "Buceo, senderismo, observacion de ballenas, avistamiento de aves, visitas historicas"
        },
        {
            "id": 3,
            "nombre": "Ensenada de Utria",
            "municipio": "Nuqui",
            "categoria": "Natural",
            "descripcion": "Un fiordo natural donde la selva se encuentra con el mar, ideal para kayak y observacion de delfines.",
            "descripcion_detallada": "La Ensenada de Utria es considerada una de las maravillas naturales del Choco y de Colombia. Esta ensenada natural, formada por la interseccion del rio y el mar Pacifico, crea un ecosistema unico donde las aguas calmas permiten la observacion de delfines nariz de botella, ballenas y una gran variedad de aves acuaticas. Las aguas termales que brotan en sus orillas la hacen un lugar especial para relajarse en medio de la naturaleza.",
            "imagen": "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800",
            "coordenadas": "2.3167° N, 77.5333° W",
            "acceso": "En lancha desde Nuqui o Bahia Solano",
            "actividades": "Kayak, observacion de delfines, natacion en aguas termales, senderismo, fotografia"
        },
        {
            "id": 4,
            "nombre": "Tutunendo",
            "municipio": "Quibdo",
            "categoria": "Natural",
            "descripcion": "Corregimiento de Quibdo conocido por sus hermosas cascadas y rios cristalinos en medio de la selva.",
            "descripcion_detallada": "Tutunendo es un corregimiento del municipio de Quibdo, reconocido por sus impresionantes cascadas y rios de aguas cristalinas. Rodeado de una exuberante selva tropical, ofrece a los visitantes la oportunidad de conectarse con la naturaleza en su estado mas puro. Sus principales atractivos incluyen el Charco de los Deseos y varias caidas de agua ideales para el ecoturismo y la fotografia de paisaje.",
            "imagen": "https://images.unsplash.com/photo-1439853949127-fa647821eba0?w=800",
            "coordenadas": "5.7500° N, 76.5500° W",
            "acceso": "Por via terrestre desde Quibdo (aproximadamente 30 minutos en carro)",
            "actividades": "Senderismo, natacion en rios, observacion de cascadas, fotografia de naturaleza, ecoturismo"
        },
        {
            "id": 5,
            "nombre": "Fiesta de San Francisco de Asis",
            "municipio": "Quibdo",
            "categoria": "Cultural",
            "descripcion": "Tradicional celebracion patronal con procesiones, musica, danzas y gastronomia tipica afrochocoana.",
            "descripcion_detallada": "La Fiesta de San Francisco de Asis es una de las celebraciones mas importantes del Choco, realizada anualmente en Quibdo. Durante varios dias, la ciudad se llena de color, musica y alegria con procesiones religiosas, presentaciones de danzas tradicionales como el abozao y el currulao, muestras gastronomicas y ferias artesanales. Es una oportunidad unica para experimentar la riqueza cultural y espiritual del pueblo chocoano.",
            "imagen": "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800",
            "coordenadas": "5.6918 N, 76.6584 W",
            "acceso": "Por via terrestre desde Medellin (10-12 horas) o por avion (1 hora) hasta Quibdo",
            "actividades": "Procesiones religiosas, danzas tradicionales, gastronomia tipica, ferias artesanales, musica en vivo"
        },
        {
            "id": 6,
            "nombre": "Capurgana",
            "municipio": "Acandi",
            "categoria": "Playa",
            "descripcion": "Paraiso caribeno en el Choco, famoso por sus playas de arena blanca, aguas cristalinas y arrecifes de coral.",
            "descripcion_detallada": "Capurgana es un corregimiento del municipio de Acandi, ubicado en la frontera con Panama, en la costa del Caribe chocoano. Es famoso por sus espectaculares playas de arena blanca y aguas cristalinas rodeadas de selva tropical. El arrecife de coral de Capurgana alberga una variada vida marina ideal para el buceo y el snorkel. El sendero ecologico que conecta Capurgana con Sapzurro ofrece vistas panoramicas del Caribe y la selva.",
            "imagen": "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
            "coordenadas": "8.6333 N, 77.3500 W",
            "acceso": "Por avion desde Medellin hasta Acandi (1 hora) y luego en lancha (30 minutos) o por via maritima desde Necocli o Turbo",
            "actividades": "Snorkel, buceo, senderismo, playa, avistamiento de aves, visita a Sapzurro"
        }
    ]
    if not os.path.exists(DESTINOS_PATH):
        save_destinos(destinos_iniciales)
    print("=" * 50)
    print("  Directorio Turistico del Choco")
    print("  http://127.0.0.1:5050")
    print("  Admin: admin@choco.gov.co / admin123")
    print("=" * 50)
    app.run(debug=True, port=5050)
