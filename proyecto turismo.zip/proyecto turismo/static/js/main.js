function toggleUserMenu() {
    const menu = document.getElementById('user-menu');
    menu.classList.toggle('hidden');
}

function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    menu.classList.toggle('hidden');
}

function confirmarEliminar(event, item) {
    event.preventDefault();
    const form = event.target;
    if (confirm('Estas seguro de que deseas eliminar ' + item + '? Esta accion no se puede deshacer.')) {
        form.submit();
    }
    return false;
}

document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('click', function(event) {
        const userMenuContainer = document.getElementById('user-menu-container');
        const userMenu = document.getElementById('user-menu');
        if (userMenuContainer && userMenu && !userMenuContainer.contains(event.target)) {
            userMenu.classList.add('hidden');
        }
    });

    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(function(msg) {
        setTimeout(function() {
            msg.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
            msg.style.opacity = '0';
            msg.style.transform = 'translateY(-10px)';
            setTimeout(function() {
                msg.remove();
            }, 500);
        }, 4000);
    });
});
