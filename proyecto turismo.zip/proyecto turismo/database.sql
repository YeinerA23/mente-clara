CREATE DATABASE IF NOT EXISTS turismo_choco
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE turismo_choco;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol VARCHAR(20) NOT NULL DEFAULT 'usuario',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- El admin se crea automaticamente al ejecutar python app.py
-- Credenciales: admin@choco.gov.co / admin123
