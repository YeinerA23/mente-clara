# Directorio Turistico Digital del Choco

Proyecto web universitario - Desarrollo Web

## Tecnologias

- Python 3
- Flask
- HTML5
- Tailwind CSS
- JavaScript ES6
- MySQL (XAMPP / phpMyAdmin)

## Requisitos

- XAMPP con MySQL iniciado
- Python 3

## Instalacion

1. **Importar la base de datos** en phpMyAdmin:
   - Abre phpMyAdmin (http://localhost/phpmyadmin)
   - Ve a la pestana "Importar"
   - Selecciona el archivo `database.sql`
   - Haz clic en "Continuar"

2. **Instalar dependencias de Python:**
   ```
   pip install -r requirements.txt
   ```

3. **Ejecutar el proyecto:**
   ```
   python app.py
   ```

4. Abrir http://127.0.0.1:5050

## Credenciales de administrador

- **Email:** admin@choco.gov.co
- **Contrasena:** admin123

## Configurar conexion MySQL

Si tu XAMPP usa credenciales diferentes, usa variables de entorno:

```
set DB_HOST=localhost
set DB_PORT=3306
set DB_USER=root
set DB_PASS=
set DB_NAME=turismo_choco
```

## Estructura

```
proyecto/
  app.py              - Aplicacion principal Flask
  requirements.txt    - Dependencias de Python
  database.sql        - Script SQL para importar en phpMyAdmin
  destinos.json       - Datos de destinos turisticos
  static/
    css/style.css     - Estilos personalizados
    js/main.js        - Funcionalidad JavaScript
    img/              - Imagenes estaticas
    favicon.ico       - Icono del sitio
  templates/
    base.html         - Plantilla base
    index.html        - Pagina principal
    login.html        - Inicio de sesion
    registro.html     - Registro de usuarios
    destinos.html     - Lista de destinos
    detalle.html      - Detalle de destino
    404.html          - Pagina no encontrada
    admin/
      panel.html      - Panel de administracion
      form_destino.html - Formulario crear/editar destino
      usuarios.html   - Gestion de usuarios
```
