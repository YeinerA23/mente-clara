# ============================================================
# Mente Clara · Aplicación Flask
# Ejecutar: python app.py  →  http://localhost:5000
# ============================================================

import os, uuid
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, abort, send_from_directory)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import mysql.connector

app = Flask(__name__)
app.secret_key = "mc-secret-2026-cambiar-en-produccion"
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'img', 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
ALLOWED_EXT = {'png','jpg','jpeg','gif','webp'}

# ---------- MySQL ----------
def get_db():
    return mysql.connector.connect(host="localhost", user="root", password="",
                                   database="mente_clara_db", autocommit=True)

# ---------- Decoradores ----------
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'usuario_id' not in session:
            flash('Debes iniciar sesión para acceder.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def get_user():
    if 'usuario_id' not in session: return None
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM usuarios WHERE id=%s", (session['usuario_id'],))
    user = cur.fetchone(); cur.close(); db.close()
    return user

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

@app.context_processor
def inject_user():
    return dict(current_user=get_user())

# ============================================================
# RUTA PÚBLICA (landing para visitantes)
# ============================================================
@app.route('/')
def landing():
    if 'usuario_id' in session:
        return redirect(url_for('inicio'))
    return render_template('landing.html')

# ============================================================
# RUTAS PROTEGIDAS (requieren sesión)
# ============================================================
@app.route('/inicio')
@login_required
def inicio():
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM servicios WHERE activo=1 LIMIT 6")
    servicios = cur.fetchall()
    cur.execute("SELECT * FROM testimonios WHERE aprobado=1 ORDER BY RAND() LIMIT 6")
    testimonios = cur.fetchall()
    cur.execute("SELECT * FROM articulos_blog WHERE publicado=1 ORDER BY creado_en DESC LIMIT 3")
    articulos = cur.fetchall()
    cur.close(); db.close()
    return render_template('inicio.html', servicios=servicios,
                           testimonios=testimonios, articulos=articulos)

@app.route('/login', methods=['GET','POST'])
def login():
    if 'usuario_id' in session: return redirect(url_for('inicio'))
    if request.method == 'POST':
        correo = request.form.get('correo','').strip().lower()
        clave = request.form.get('clave','')
        recordar = request.form.get('recordar')
        if not correo or not clave:
            flash('Ingresa tu correo y contraseña.','error')
            return redirect(url_for('login'))
        db = get_db(); cur = db.cursor(dictionary=True)
        cur.execute("SELECT * FROM usuarios WHERE correo=%s AND activo=1",(correo,))
        user = cur.fetchone(); cur.close(); db.close()
        if user and check_password_hash(user['clave'], clave):
            session['usuario_id'] = user['id']
            session['nombre'] = user['nombre']
            session.permanent = bool(recordar)
            flash(f"¡Bienvenido, {user['nombre']}!",'exito')
            nxt = request.args.get('next','')
            return redirect(nxt if nxt else url_for('inicio'))
        flash('Correo o contraseña incorrectos.','error')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/registro', methods=['GET','POST'])
def registro():
    if 'usuario_id' in session: return redirect(url_for('inicio'))
    if request.method == 'POST':
        nombre = request.form.get('nombre','').strip()
        apellidos = request.form.get('apellidos','').strip()
        correo = request.form.get('correo','').strip().lower()
        telefono = request.form.get('telefono','').strip()
        fecha_nac = request.form.get('fecha_nacimiento','').strip()
        genero = request.form.get('genero','prefiero_no_decir')
        clave = request.form.get('clave','')
        clave2 = request.form.get('clave2','')
        if not nombre or not apellidos or not correo or not clave or not clave2:
            flash('Completa todos los campos obligatorios.','error')
            return redirect(url_for('registro'))
        if len(clave) < 6:
            flash('La contraseña debe tener al menos 6 caracteres.','error')
            return redirect(url_for('registro'))
        if clave != clave2:
            flash('Las contraseñas no coinciden.','error')
            return redirect(url_for('registro'))
        db = get_db(); cur = db.cursor(dictionary=True)
        cur.execute("SELECT id FROM usuarios WHERE correo=%s",(correo,))
        if cur.fetchone():
            cur.close(); db.close()
            flash('Ese correo ya está registrado.','error')
            return redirect(url_for('registro'))
        hashed = generate_password_hash(clave)
        cur.execute("INSERT INTO usuarios(nombre,apellidos,correo,telefono,fecha_nacimiento,genero,clave) VALUES(%s,%s,%s,%s,%s,%s,%s)",
                    (nombre,apellidos,correo,telefono,fecha_nac or None,genero,hashed))
        cur.close(); db.close()
        flash('Cuenta creada. Ya puedes iniciar sesión.','exito')
        return redirect(url_for('login'))
    return render_template('registro.html')

@app.route('/recuperar', methods=['GET','POST'])
def recuperar():
    if request.method == 'POST':
        correo = request.form.get('correo','').strip().lower()
        nueva = request.form.get('nueva_clave','')
        clave2 = request.form.get('clave2','')
        if not correo or not nueva or not clave2:
            flash('Completa todos los campos.','error')
            return redirect(url_for('recuperar'))
        if len(nueva) < 6:
            flash('Mínimo 6 caracteres.','error')
            return redirect(url_for('recuperar'))
        if nueva != clave2:
            flash('Las contraseñas no coinciden.','error')
            return redirect(url_for('recuperar'))
        db = get_db(); cur = db.cursor(dictionary=True)
        cur.execute("SELECT id FROM usuarios WHERE correo=%s",(correo,))
        user = cur.fetchone()
        if not user:
            cur.close(); db.close()
            flash('No se encontró cuenta con ese correo.','error')
            return redirect(url_for('recuperar'))
        cur.execute("UPDATE usuarios SET clave=%s WHERE id=%s",(generate_password_hash(nueva), user['id']))
        cur.close(); db.close()
        flash('Contraseña actualizada.','exito')
        return redirect(url_for('login'))
    return render_template('recuperar.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada.','exito')
    return redirect(url_for('login'))

@app.route('/servicios')
@login_required
def servicios():
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM servicios WHERE activo=1")
    items = cur.fetchall(); cur.close(); db.close()
    return render_template('servicios.html', servicios=items)

@app.route('/proceso')
@login_required
def proceso(): return render_template('proceso.html')

@app.route('/sobre-mi')
@login_required
def sobre_mi():
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM psicologos WHERE activo=1 LIMIT 1")
    psi = cur.fetchone(); cur.close(); db.close()
    return render_template('sobre_mi.html', psicologo=psi)

@app.route('/testimonios')
@login_required
def testimonios_page():
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM testimonios WHERE aprobado=1 ORDER BY creado_en DESC")
    items = cur.fetchall(); cur.close(); db.close()
    return render_template('testimonios.html', testimonios=items)

@app.route('/blog')
@login_required
def blog():
    db = get_db(); cur = db.cursor(dictionary=True)
    cat = request.args.get('cat','')
    if cat:
        cur.execute("""SELECT a.*, c.nombre AS cat_nombre FROM articulos_blog a
            LEFT JOIN categorias_blog c ON a.categoria_id=c.id
            WHERE a.publicado=1 AND c.slug=%s ORDER BY a.creado_en DESC""",(cat,))
    else:
        cur.execute("""SELECT a.*, c.nombre AS cat_nombre FROM articulos_blog a
            LEFT JOIN categorias_blog c ON a.categoria_id=c.id
            WHERE a.publicado=1 ORDER BY a.creado_en DESC""")
    arts = cur.fetchall()
    cur.execute("SELECT * FROM categorias_blog")
    cats = cur.fetchall(); cur.close(); db.close()
    return render_template('blog.html', articulos=arts, categorias=cats)

@app.route('/blog/<slug>')
@login_required
def blog_articulo(slug):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("""SELECT a.*, c.nombre AS cat_nombre FROM articulos_blog a
        LEFT JOIN categorias_blog c ON a.categoria_id=c.id
        WHERE a.slug=%s AND a.publicado=1""",(slug,))
    art = cur.fetchone()
    if not art: cur.close(); db.close(); abort(404)
    cur.execute("SELECT * FROM articulos_blog WHERE publicado=1 AND id!=%s ORDER BY RAND() LIMIT 3",(art['id'],))
    rels = cur.fetchall(); cur.close(); db.close()
    return render_template('blog_articulo.html', articulo=art, relacionados=rels)

@app.route('/contacto', methods=['GET','POST'])
@login_required
def contacto():
    if request.method == 'POST':
        nombre = request.form.get('nombre','').strip()
        email = request.form.get('email','').strip()
        telefono = request.form.get('telefono','').strip()
        asunto = request.form.get('asunto','').strip()
        mensaje = request.form.get('mensaje','').strip()
        if not nombre or not email or not asunto or not mensaje:
            flash('Completa todos los campos obligatorios.','error')
            return redirect(url_for('contacto'))
        db = get_db(); cur = db.cursor()
        cur.execute("INSERT INTO contactos(nombre,email,telefono,asunto,mensaje) VALUES(%s,%s,%s,%s,%s)",
                    (nombre,email,telefono,asunto,mensaje))
        cur.close(); db.close()
        flash('¡Mensaje enviado! Te responderemos pronto.','exito')
        return redirect(url_for('contacto'))
    return render_template('contacto.html')

# ============================================================
# PRIVADAS
# ============================================================
@app.route('/perfil')
@login_required
def perfil():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) AS t FROM citas WHERE usuario_id=%s",(user['id'],))
    total = cur.fetchone()['t']
    cur.execute("SELECT COUNT(*) AS t FROM citas WHERE usuario_id=%s AND estado='pendiente'",(user['id'],))
    pend = cur.fetchone()['t']; cur.close(); db.close()
    return render_template('perfil.html', user=user, total_citas=total, citas_pendientes=pend)

@app.route('/editar-perfil', methods=['GET','POST'])
@login_required
def editar_perfil():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    if request.method == 'POST':
        nombre = request.form.get('nombre','').strip()
        apellidos = request.form.get('apellidos','').strip()
        telefono = request.form.get('telefono','').strip()
        fecha_nac = request.form.get('fecha_nacimiento','').strip()
        genero = request.form.get('genero','prefiero_no_decir')
        if not nombre or not apellidos:
            flash('Nombre y apellidos son obligatorios.','error')
            return redirect(url_for('editar_perfil'))
        db = get_db(); cur = db.cursor()
        cur.execute("UPDATE usuarios SET nombre=%s,apellidos=%s,telefono=%s,fecha_nacimiento=%s,genero=%s WHERE id=%s",
                    (nombre,apellidos,telefono,fecha_nac or None,genero,user['id']))
        cur.close(); db.close()
        session['nombre'] = nombre
        flash('Perfil actualizado.','exito')
        return redirect(url_for('perfil'))
    return render_template('editar_perfil.html', user=user)

@app.route('/cambiar-foto', methods=['POST'])
@login_required
def cambiar_foto():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    if 'foto' not in request.files:
        flash('Selecciona una imagen.','error')
        return redirect(url_for('editar_perfil'))
    f = request.files['foto']
    if f.filename == '':
        flash('Selecciona una imagen.','error')
        return redirect(url_for('editar_perfil'))
    if f and allowed_file(f.filename):
        ext = f.filename.rsplit('.',1)[1].lower()
        fn = f"user_{user['id']}_{uuid.uuid4().hex[:8]}.{ext}"
        f.save(os.path.join(app.config['UPLOAD_FOLDER'], fn))
        if user['foto'] != 'default.png':
            old = os.path.join(app.config['UPLOAD_FOLDER'], user['foto'])
            if os.path.exists(old): os.remove(old)
        db = get_db(); cur = db.cursor()
        cur.execute("UPDATE usuarios SET foto=%s WHERE id=%s",(fn,user['id']))
        cur.close(); db.close()
        flash('Foto actualizada.','exito')
    else:
        flash('Formato no válido.','error')
    return redirect(url_for('editar_perfil'))

@app.route('/cambiar-contrasena', methods=['GET','POST'])
@login_required
def cambiar_contrasena():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    if request.method == 'POST':
        actual = request.form.get('actual','')
        nueva = request.form.get('nueva','')
        nueva2 = request.form.get('nueva2','')
        if not actual or not nueva or not nueva2:
            flash('Completa todos los campos.','error')
            return redirect(url_for('cambiar_contrasena'))
        if not check_password_hash(user['clave'], actual):
            flash('La contraseña actual es incorrecta.','error')
            return redirect(url_for('cambiar_contrasena'))
        if len(nueva) < 6:
            flash('Mínimo 6 caracteres.','error')
            return redirect(url_for('cambiar_contrasena'))
        if nueva != nueva2:
            flash('Las contraseñas nuevas no coinciden.','error')
            return redirect(url_for('cambiar_contrasena'))
        db = get_db(); cur = db.cursor()
        cur.execute("UPDATE usuarios SET clave=%s WHERE id=%s",(generate_password_hash(nueva),user['id']))
        cur.close(); db.close()
        flash('Contraseña cambiada.','exito')
        return redirect(url_for('perfil'))
    return render_template('cambiar_contrasena.html')

@app.route('/mis-citas')
@login_required
def mis_citas():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("""SELECT c.*, s.nombre AS servicio_nombre FROM citas c
        LEFT JOIN servicios s ON c.servicio_id=s.id
        WHERE c.usuario_id=%s ORDER BY c.fecha DESC, c.hora DESC""",(user['id'],))
    citas = cur.fetchall(); cur.close(); db.close()
    return render_template('mis_citas.html', citas=citas)

@app.route('/agendar', methods=['GET','POST'])
@login_required
def agendar():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM servicios WHERE activo=1")
    servicios = cur.fetchall()
    cur.execute("SELECT * FROM psicologos WHERE activo=1")
    psicologos = cur.fetchall()
    if request.method == 'POST':
        sid = request.form.get('servicio_id','')
        pid = request.form.get('psicologo_id','')
        snom = request.form.get('servicio_nombre','').strip()
        fecha = request.form.get('fecha','').strip()
        hora = request.form.get('hora','').strip()
        modalidad = request.form.get('modalidad','virtual')
        notas = request.form.get('notas','').strip()
        if not fecha or not hora:
            flash('Selecciona fecha y hora.','error')
            return redirect(url_for('agendar'))
        cur.execute("""INSERT INTO citas(usuario_id,servicio_id,psicologo_id,
            nombre_completo,telefono,email,servicio,fecha,hora,modalidad,notas)
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (user['id'],sid or None,pid or None,
             f"{user['nombre']} {user.get('apellidos','')}".strip(),
             user.get('telefono',''),user.get('correo',''),snom,fecha,hora,modalidad,notas))
        cur.close(); db.close()
        flash('¡Cita agendada! Te contactaremos para confirmar.','exito')
        return redirect(url_for('mis_citas'))
    cur.close(); db.close()
    return render_template('agendar.html', servicios=servicios, psicologos=psicologos, user=user)

@app.route('/cancelar-cita/<int:cita_id>', methods=['POST'])
@login_required
def cancelar_cita(cita_id):
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM citas WHERE id=%s AND usuario_id=%s",(cita_id,user['id']))
    if not cur.fetchone():
        cur.close(); db.close()
        flash('Cita no encontrada.','error')
        return redirect(url_for('mis_citas'))
    cur.execute("UPDATE citas SET estado='cancelada' WHERE id=%s",(cita_id,))
    cur.close(); db.close()
    flash('Cita cancelada.','exito')
    return redirect(url_for('mis_citas'))

@app.route('/configuracion', methods=['GET','POST'])
@login_required
def configuracion():
    user = get_user()
    if not user: session.clear(); return redirect(url_for('login'))
    if request.method == 'POST':
        accion = request.form.get('accion','')
        if accion == 'eliminar_cuenta':
            db = get_db(); cur = db.cursor()
            if user['foto'] != 'default.png':
                fp = os.path.join(app.config['UPLOAD_FOLDER'], user['foto'])
                if os.path.exists(fp): os.remove(fp)
            cur.execute("DELETE FROM usuarios WHERE id=%s",(user['id'],))
            cur.close(); db.close()
            session.clear()
            flash('Cuenta eliminada.','info')
            return redirect(url_for('login'))
    return render_template('configuracion.html', user=user)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.errorhandler(404)
def not_found(e): return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e): return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
